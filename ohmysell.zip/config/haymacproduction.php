<?php

/**
     * Author    : Elmarzougui Abdelghafour (Haymacproduction)
 * website   : https://www.elmarzougui.com
 * linkedin  : https://www.linkedin.com/in/devscript/
 * facebook  : https://www.facebook.com/devscript
 * twitter   : https://twitter.com/devscriptt
 * createdAt : 13/novembre/2020
 **/

return [

    'getFrom' => 'cache',

    /****Admin Url */
    
    'ADMIN_DASH_PREFIX' => env('ADMIN_DASH_PREFIX', 'admin'),

    'DILEVERY_DASH_PREFIX' => env('DILEVERY_DASH_PREFIX', 'app')
];
