<?php

namespace App\Hooks\Validator\Repository;


interface ValidatorHookInterface
{

    // public function isValid();

    public function platforms();
}
