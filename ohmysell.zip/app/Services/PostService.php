<?php
namespace App\Services;

class PostService {

    protected $post;

    public function __construct()
    {

    }


}
