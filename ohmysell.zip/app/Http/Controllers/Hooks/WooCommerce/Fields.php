<?php

namespace App\Http\Controllers\Hooks\WooCommerce;

Class Fields {

   
    const FNAME ='name';
    const LNAME ='name';
    public function __construct()
    {
        
    }
    

    
}