<?php

namespace App\Http\Livewire\Product;

interface ProductsFilters
{

    public function __construct($allowedsFilters);

 
}
