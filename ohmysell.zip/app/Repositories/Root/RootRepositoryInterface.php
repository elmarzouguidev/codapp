<?php

namespace App\Repositories\Root;

interface RootRepositoryInterface
{

    function sendNotificationToBrowser($options);
   

}
