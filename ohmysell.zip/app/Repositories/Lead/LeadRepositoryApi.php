<?php

namespace App\Repositories\Lead;

class LeadRepositoryApi implements LeadRepositoryInterface
{


    /**
     * @return mixed
     */
    public function all()
    {
        // TODO: Implement all() method.
    }

    /**
     * @param $id
     * @return mixed
     */
    public function find($id)
    {
        // TODO: Implement find() method.
    }

    /**
     * @param int $id
     * @return mixed
     */
    public function findOrFail(int $id)
    {
        // TODO: Implement findOrFail() method.
    }

    /**
     * @param array $attributes
     * @return mixed
     */
    public function create(array $attributes)
    {
        // TODO: Implement create() method.
    }

    /**
     * @param array $attributes
     * @param $id
     * @return mixed
     */
    public function update(array $attributes, $id)
    {
        // TODO: Implement update() method.
    }

    /**
     * @param int $id
     * @return mixed
     */
    public function delete(int $id)
    {
        // TODO: Implement delete() method.
    }

    /**
     * @param $id
     * @return mixed
     */
    public function destroy($id)
    {
        // TODO: Implement destroy() method.
    }

    /**
     * @param $page
     * @return mixed
     */
    public function paginate($page)
    {
        // TODO: Implement paginate() method.
    }

    /**
     * @return mixed
     */
    public function query()
    {
        // TODO: Implement query() method.
    }

    /**
     * @return mixed
     */
    public function forLoggedUser()
    {
        // TODO: Implement forLoggedUser() method.
    }

    /**
     * @return mixed
     */
    public function auth()
    {
        // TODO: Implement auth() method.
    }
}
